Paper writing package: Gemini 3.1 Pro Preview vs Gemini 3 Flash Preview

Contents:
- tables/
  - valid_outputs.csv
  - numeric_main_metrics.csv
  - global_summary_filtered.csv
  - run_variability_filtered.csv
  - topic_level_means_filtered.csv
  - metrics_filtered_validity_source.csv
  - paper_writing_tables.xlsx
- figures/
  - chart_in_corpus_rate.png
  - chart_invalid_id_rate.png
  - chart_unknown_id_rate.png
  - chart_n_refs.png
  - chart_panel_main_metrics.png
  - heatmap_in_corpus_rate_by_topic.png
  - heatmap_invalid_id_rate_by_topic.png
- texts/
  - summary.txt
  - summary.json

Use case:
This package is intended to help an LLM or a human writer draft the Results,
Discussion, Limitations, and figure/table descriptions for the paper.
